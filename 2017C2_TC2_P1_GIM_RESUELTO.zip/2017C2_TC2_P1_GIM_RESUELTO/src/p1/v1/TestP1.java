package p1.v1;

import p1.v1.clases.Gimnasio;

public class TestP1 {

	public static void main(String[] args) {
		Gimnasio gym = new Gimnasio();

		String dniMariano = "1234";
		String dniGaby = "5678";
		String dniDany = "5712";

		gym.ingresarSocio(dniMariano, "Mariano Aquino", "15-1234-5678", 31);
		gym.ingresarSocio(dniGaby, "Gabriel Stancanelli", "15-5678-1234", 40);
		gym.ingresarSocio(dniDany, "Dany Vazquez", "15-3354-5544", 40);

		gym.registrarActividad(dniMariano, "Aerobico", "2017-09-11");
		gym.registrarActividad(dniMariano, "Aerobico", "2017-09-18");
		gym.registrarActividad(dniMariano, "Rubik", "2017-09-18");

		gym.registrarActividad(dniGaby, "Judo", "2017-09-04");
		gym.registrarActividad(dniGaby, "Judo", "2017-09-11");
		gym.registrarActividad(dniGaby, "Judo", "2017-09-18");
		gym.registrarActividad(dniGaby, "Judo", "2017-09-25");

		gym.suspenderSocio(dniDany);
		gym.registrarActividad(dniDany, "Judo", "2017-09-04");
		gym.levantarSuspensionSocio(dniDany);
		gym.registrarActividad(dniDany, "Judo", "2017-09-11");

		gym.mostrarSocioMaxAsistencias();
		gym.darDeBaja(dniGaby);
		gym.mostrarSocioMaxAsistencias();

		gym.resolverFacturacion(dniMariano);
		gym.resolverFacturacion(dniMariano);
		gym.resolverFacturacion(dniDany);
	}

}
