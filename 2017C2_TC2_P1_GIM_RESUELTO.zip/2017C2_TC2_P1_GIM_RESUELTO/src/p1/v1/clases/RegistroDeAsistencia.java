package p1.v1.clases;

public class RegistroDeAsistencia {

	private String fecha;
	private String nombreActividad;
	private double precio;
	private boolean abonada;
	/**
	 * @param fecha fecha de la actividad
	 * @param nombreActividad nombre de la actividad
	 * @param precio el precio actual de la actividad
	 */
	public RegistroDeAsistencia(String fecha, String nombreActividad, double precio) {
		this.fecha = fecha;
		this.nombreActividad = nombreActividad;
		this.precio = precio;
		this.abonada = false;
	}
	/**
	 * @return la fecha de la actividad
	 */
	public String getFecha() {
		return fecha;
	}
	/**
	 * @return el nombre de la Actividad
	 */
	public String getNombreActividad() {
		return nombreActividad;
	}
	/**
	 * @return el precio
	 */
	public double getPrecio() {
		return precio;
	}
	/**
	 * @return si esta abonada
	 */
	public boolean estaAbonada() {
		return abonada;
	}
	public void darPorAbonada() {
		abonada = true;		
	}

	@Override
	public String toString() {
		return "RegistroDeAsistencia [fecha=" + fecha + ", nombreActividad=" + nombreActividad + ", precio=" + precio
				+ ", abonada=" + abonada + "]";
	}
	
	
}
