package p1.v1.clases;

import java.util.ArrayList;

public class Socio {

	private String dni;
	private String nombre;
	private String telefono;
	private int edad;
	private boolean suspendido;
	private ArrayList<RegistroDeAsistencia> registroAsistencias;

	/**
	 * @param dni
	 *            DNI del socio (es la clave por la cual se buscara).
	 * @param nombre
	 *            Nombre del socio.
	 * @param telefono
	 *            Telefono del socio.
	 * @param edad
	 *            Edad del socio.
	 */
	public Socio(String dni, String nombre, String telefono, int edad) {
		this.dni = dni;
		this.nombre = nombre;
		this.telefono = telefono;
		this.edad = edad;
		this.suspendido = false;
		this.registroAsistencias = new ArrayList<>();
	}

	/**
	 * Registra la asistencia del socio a una actividad para que sirva de
	 * registro al momento de liquidar.
	 * 
	 * @param fecha
	 *            la fecha en la cual concurre a la actividad
	 * @param actividad
	 *            Actividad a la que concurre.
	 */
	public void registrarAsistencia(String fecha, Actividad actividad) {
		registroAsistencias.add(new RegistroDeAsistencia(fecha, actividad.getNombre(), actividad.getPrecio()));
	}

	/**
	 * Suspende al socio poniendo el atributo suspendido del socio en true.
	 * Podria hacer mas cosas, como guardar la fecha de cambio de estado en
	 * alguna otra bitacora.
	 */
	public void suspender() {
		suspendido = true;
	}

	/**
	 * Levanta la suspensi�n poniendo el atributo suspendido del socio en false.
	 * Podria hacer mas cosas, como guardar la fecha de cambio de estado en
	 * alguna otra bitacora.
	 */
	public void levantarSuspension() {
		suspendido = false;
	}

	/**
	 * @return el nombre del socio
	 */
	public String getNombre() {
		return nombre;
	}

	/**
	 * @return el DNI del socio (es la clave para identificarlo)
	 */
	public Object getDni() {
		return dni;
	}

	/**
	 * @return el telefono del socio
	 */
	public String getTelefono() {
		return telefono;
	}

	/**
	 * @return la edad del socio
	 */
	public int getEdad() {
		return edad;
	}

	/**
	 * @return un booleano que indica si el socio est� suspendido.
	 */
	public boolean estaSuspendido() {
		return suspendido;
	}

	/**
	 * @param nombre
	 *            el nombre del socio
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/**
	 * @param telefono
	 *            el telefono a setear.
	 */
	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	/**
	 * @param edad
	 *            the edad to set
	 */
	public void setEdad(int edad) {
		this.edad = edad;
	}

	/**
	 * Liquida las asistencias al gimnasio no abonadas: Muestra cada asistencia,
	 * acumula el importe y marca la asistencia como abonada.
	 * 
	 * @return el importe a abonar.
	 */
	public double liquidar() {
		double importe = 0;
		for (RegistroDeAsistencia registroDeAsistencia : registroAsistencias) {
			if (!registroDeAsistencia.estaAbonada()) {
				System.out.println(registroDeAsistencia);
				importe += registroDeAsistencia.getPrecio();
				registroDeAsistencia.darPorAbonada();
			}
		}
		return importe;
	}

	/**
	 * @return la cantidad total de asistencias
	 */
	public int getCantidadAsistencias() {
		return registroAsistencias.size();
	}

}
