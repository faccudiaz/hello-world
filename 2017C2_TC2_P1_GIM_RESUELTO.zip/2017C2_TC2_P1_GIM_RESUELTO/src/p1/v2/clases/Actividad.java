package p1.v2.clases;

public class Actividad {
	private String nombre;
	private double precio;
	/**
	 * @param nombre Nombre de la actividad
	 * @param precio precio de una asistencia a la actividad
	 */
	public Actividad(String nombre, double precio) {
		this.nombre = nombre;
		this.precio = precio;
	}
	/**
	 * @return el nombre
	 */
	public String getNombre() {
		return nombre;
	}
	/**
	 * @return el precio
	 */
	public double getPrecio() {
		return precio;
	}

	@Override
	public String toString() {
		return "Actividad [nombre=" + nombre + ", precio=" + precio + "]";
	}

}
