package p1.v2.clases;

import java.util.ArrayList;
import java.util.Scanner;

public class Gimnasio {

	private static final int CANT_ACTIVIDADES = 10;
	private final Scanner input;
	private Actividad[] actividades;
	private ArrayList<Socio> socios;

	/**
	 * Inicializa el gimnasio creando las estructuras para guardar actividades y
	 * socios. Adem�s carga las actividades que realiza el socio en este
	 * momento.
	 */
	public Gimnasio(Scanner scanner) {
		this.input = scanner;
		this.actividades = new Actividad[CANT_ACTIVIDADES];
		this.socios = new ArrayList<>();
		cargarActividades();
	}

	/**
	 * Carga las actividades que realiza el socio en este momento.
	 */
	private void cargarActividades() {
		actividades[0] = new Actividad("Aerobico", 40);
		actividades[1] = new Actividad("Judo", 80);
	}

	/**
	 * Crea y procesa el ingreso de un socio al gimnasio. Si el socio ya existe
	 * se informara por pantalla.
	 * 
	 * @param dni
	 *            DNI del socio
	 * @param nombre
	 *            Nombre del socio
	 * @param telefono
	 *            Telefono del socio
	 * @param edad
	 *            Edad del socio
	 */
	public void ingresarSocio(String dni, String nombre, String telefono, int edad) {
		Socio socio = buscarSocio(dni);
		if (socio == null) {
			socios.add(new Socio(dni, nombre, telefono, edad));
		} else {
			System.out.println("El socio ya existe");
		}
	}

	/**
	 * Busca un socio a partir de su DNI entre los socios registrados del
	 * gimnasio.
	 * 
	 * @param dni
	 *            DNI del socio
	 * @return El socio. Si no lo encuentra devuelve null.
	 */
	private Socio buscarSocio(String dni) {
		int i = 0;
		Socio socio = null;
		while (i < socios.size() && !socios.get(i).getDni().equals(dni)) {
			i++;
		}
		if (i < socios.size()) {
			socio = socios.get(i);
		}
		return socio;
	}

	/**
	 * Registra la actividad del socio en el gimnasio. Si no lo encuentra o si
	 * el socio esta suspendido, se informa por pantalla el error y la actividad
	 * no se registra.
	 * 
	 * @param dni
	 *            DNI del socio
	 * @param nombreActividad
	 *            nombre de la actividad
	 * @param fecha
	 *            fecha para la cual se registra la actividad
	 */
	public void registrarActividad(String dni, String nombreActividad, String fecha) {
		Socio socio = buscarSocio(dni);
		if (socio != null) {
			if (socio.estaSuspendido()) {
				System.out.println(socio.getNombre() + " esta suspendido y no puede hacer " + nombreActividad
						+ " ni ninguna otra actividad.");
			} else {
				Actividad actividad = buscoActividad(nombreActividad);
				if (actividad == null) {
					System.out.println("La actividad " + nombreActividad + " no existe");
				} else {
					// tengo un socio valido y una actividad valida, entonces la
					// creo
					socio.registrarAsistencia(fecha, actividad);
					System.out.println("Se registro la asistencia de " + socio.getNombre() + " a " + nombreActividad
							+ " el " + fecha);
				}
			}
		} else {
			System.out.println("El socio no existe");
		}
	}

	/**
	 * Busco una actividad a partir de su nombre.
	 * 
	 * @param nombreActividad
	 *            Nombre de la actividad
	 * @return la actividad o null, si la misma no existe.
	 */
	private Actividad buscoActividad(String nombreActividad) {
		int i = 0;
		Actividad actividad = null;
		// Para buscar la actividad debo tener en cuenta tres cosas: no debo
		// caerme de la estructura (estatica y limitada en su tama�o desde su
		// creacion), y se buscara mientras no encuentre un lugar vacio en el
		// arreglo (porque puede ser que el gimnasio no realice todas las
		// actividades que puede realizar) y mientras no haya encontrado la
		// actividad (coincidan ambos nombres).
		while (i < actividades.length && actividades[i] != null
				&& !nombreActividad.equals(actividades[i].getNombre())) {
			i++;
		}
		// Si no me cai de la estructura y la posicion no esta vacia, entonces
		// encontre lo que estaba buscando. Me lo guardo.
		if (i < actividades.length && actividades[i] != null) {
			actividad = actividades[i];
		}
		return actividad;
	}

	/**
	 * Marca a un socio como suspendido.
	 * 
	 * @param dni
	 *            DNI del socio a suspender.
	 */
	public void suspenderSocio(String dni) {
		Socio socio = buscarSocio(dni);
		if (socio != null) {
			socio.suspender();
			System.out.println("Se suspendi� a " + socio.getNombre());
		} else {
			System.out.println("El socio no existe");
		}
	}

	/**
	 * Levanta la suspensi�n a un socio.
	 * 
	 * @param dni
	 *            DNI del socio a quien se le quiere levantar la suspension.
	 */
	public void levantarSuspensionSocio(String dni) {
		Socio socio = buscarSocio(dni);
		if (socio != null) {
			socio.levantarSuspension();
			System.out.println("Se levant� la suspensi�n de " + socio.getNombre());
		} else {
			System.out.println("El socio no existe");
		}
	}

	/**
	 * Calcula quien fue el socio con mayor cantidad de asistencias, sin
	 * importar cual fue la actividad, y lo muestra.
	 */
	public void mostrarSocioMaxAsistencias() {
		int maxAsistencias = 0;
		Socio maxSocio = null;
		for (Socio socio : socios) {
			int cant = socio.getCantidadAsistencias();
			if (cant > maxAsistencias) {
				maxSocio = socio;
				maxAsistencias = cant;
			}
		}
		if (maxSocio != null) {
			System.out.println("El socio con mas asistencias es: " + maxSocio.getNombre());
		} else {
			System.out.println("no hay asistencias registradas");
		}
	}

	/**
	 * Da de baja a un socio
	 * 
	 * @param dni
	 *            DNI del socio a dar de baja.
	 */
	public void darDeBaja(String dni) {
		Socio socio = buscarSocio(dni);
		if (socio != null) {
			// SI el socio registra una deuda, se la liquida.
			if (socio.getDeudaAcumulada() > 0) {
				liquidarDeuda(dni);
			}
			// Solo si el socio cancela la deuda se lo da de baja.
			if (socio.getDeudaAcumulada() == 0) {
				socios.remove(socio);
				System.out.println("Socio " + socio.getNombre() + " fue removido con exito.");
			} else {
				System.out.println("No se puede dar de baja al socio hasta que cancele la deuda pendiente.");
			}
		} else {
			System.out.println("El socio no existe.");
		}
	}

	/**
	 * Generar un informe de asistencias para un socio en particular, ingresando
	 * su dni (de no existir mostrar "Socio Inexistente"). Dicho informe deber�:
	 * mostrar cada una de las asistencias del socio que no hayan sido abonadas,
	 * detallando: Nombre y Apellido; fecha; actividad realizada; mostrar el
	 * importe total adeudado marcar todas las asistencias mostradas como
	 * abonadas.
	 */
	public void liquidarDeuda(String dni) {
		/// busco el socio
		Socio socio = buscarSocio(dni);
		if (socio != null) {
			System.out.println("Liquidaci�n de la deuda del socio " + dni + "(" + socio.getNombre() + ")");
			double importe = socio.getDeudaAcumulada();
			if (importe == 0) {
				System.out.println("No se registra deuda, el socio est� al d�a");
			} else {
				if (preguntar(String.format("Deuda acumulada: $%s. �Cancela (S/N)?", importe))) {
					socio.cancelarDeuda();
					System.out.println("Deuda Cancelada");
				} else {
					System.out.println("La deuda sigue pendiente");
				}
			}
		} else {
			System.out.println("El socio " + dni + " no existe");
		}
	}

	/**
	 * Pregunta por verdadero o falso, validando por S/N.
	 * 
	 * @param mensaje
	 *            el mensaje a mostrar en pantalla
	 * @return verdadero si la respuesta es S (si=verdadero)
	 */
	private boolean preguntar(String pregunta) {
		// Muestra la pregunta y pasa lo que carg� el usuario a mayusculas
		System.out.println(pregunta);
		String respuesta = input.nextLine().toUpperCase();
		// aplica De Morgan para validar si es S o N
		while (!(respuesta.equals("S") || respuesta.equals("N"))) {
			System.out.println("Respuesta inv�lida. " + pregunta);
			respuesta = input.nextLine().toUpperCase();
		}
		// Al salir ser� S o N. Si es S devolvera true.
		return respuesta.equals("S");
	}

}
